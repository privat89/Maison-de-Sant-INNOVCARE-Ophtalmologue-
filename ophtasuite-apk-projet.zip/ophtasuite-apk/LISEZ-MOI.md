# OphtaSuite → APK

## Méthode 1 : GitHub (sans rien installer, ~5 min)
1. Créez un compte gratuit sur github.com, puis un nouveau dépôt (New repository).
2. Cliquez « uploading an existing file » et déposez TOUT le contenu de ce dossier
   (y compris le dossier .github — si l'interface le refuse, utilisez GitHub Desktop).
3. Onglet **Actions** → « Build APK » → attendez la coche verte.
4. Ouvrez l'exécution → section **Artifacts** → téléchargez **OphtaSuite-APK** (zip contenant app-debug.apk).
5. Copiez l'APK sur le téléphone, ouvrez-le et autorisez « installer des sources inconnues ».

## Méthode 2 : sur votre PC (Android Studio)
1. Installez Node.js 20+ et Android Studio.
2. Dans ce dossier : `npm install`, `npx cap add android`, `npx cap sync android`, `npx cap open android`
3. Android Studio → Build > Build APK(s).

## Remarques
- Polices Google : nécessitent internet au premier chargement (sinon police par défaut).
- Les données (localStorage/IndexedDB) restent sur le téléphone ; désinstaller l'app les efface : faites des sauvegardes.
- Cet APK est en mode « debug » (installable directement). Pour le Play Store, il faudra un APK/AAB signé.
